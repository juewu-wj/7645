## -----------------------------------------------------------------------------
##
##' [PROJ: EDH 7916]
##' [FILE: Data Wrangling IV: Advanced tidyverse & Data Retrieval]
##' [INIT: Jan 12th 2024]
##' [AUTH: Matt Capaldi] @ttalVlatt
##' [UPTD: Jan 12th 2025]
##
## -----------------------------------------------------------------------------

setwd(this.path::here())

## ---------------------------
##' [Libraries]
## ---------------------------

library(tidyverse)
library(dbplyr)
library(RSQLite)


## ---------------------------
##' [Read in Tidyverse Tricks Data]
## ---------------------------

data_18_pub <- read_csv("data/ipeds-finance/f1819_f1a_rv.csv")
data_18_np <- read_csv("data/ipeds-finance/f1819_f2_rv.csv")
data_18_fp <- read_csv("data/ipeds-finance/f1819_f3_rv.csv")

data_18 <- bind_rows(data_18_pub, data_18_np, data_18_fp)

data_18 |>
  count(UNITID) |>
  filter(n > 1)


## ---------------------------
##' [coalesce()-ing Split Data]
## ---------------------------

data_18 <- data_18 |>
  select(UNITID,
         F1C011, F1C021, F1C061,
         F2E011, F2E021, F2E051,
         F3E011, F3E02A1, F3E03B1)

print(data_18[100:105,])
print(data_18[3000:3005,])


## Split back up into separate files
pub <- data_18 |> filter(!is.na(F1C011)) |>
  ## Rename the variable
  rename(inst_spend = F1C011) |>
  ## Drop the other variables
  select(UNITID, inst_spend)
np <- data_18 |> filter(!is.na(F2E011)) |>
  rename(inst_spend = F2E011) |>
  select(UNITID, inst_spend)
fp <- data_18 |> filter(!is.na(F3E011)) |>
  rename(inst_spend = F3E011) |>
  select(UNITID, inst_spend)


## Re-bind the colleges back up
hard_way <- bind_rows(pub, np, fp)


easy_way <- data_18 |>
  mutate(inst_spend = coalesce(F1C011, F2E011, F3E011)) |>
  select(UNITID, inst_spend)

print(easy_way[100:105,])
print(easy_way[3000:3005,])

all.equal(hard_way, easy_way)

data_18_clean <- data_18 |>
  mutate(inst_spend = coalesce(F1C011, F2E011, F3E011),
         rsch_spend = coalesce(F1C021, F2E021, F3E02A1),
         serv_spend = coalesce(F1C061, F2E051, F3E03B1)) |>
  select(UNITID, inst_spend, rsch_spend, serv_spend)

print(data_18_clean[100:105,])
print(data_18_clean[3000:3005,])

## ---------------------------
##' [Finding if_any() Issues]
## ---------------------------

data_0_inst <- data_18_clean |> filter(inst_spend == 0)
data_0_rsch <- data_18_clean |> filter(rsch_spend == 0)
data_0_serv <- data_18_clean |> filter(serv_spend == 0)
data_0 <- bind_rows(data_0_inst, data_0_rsch, data_0_serv)

## Plus we end up with duplicates
data_0 |>
  count(UNITID) |>
  filter(n > 1)


data_0 <- data_18_clean |>
  filter(if_any(everything(), ~ . == 0)) ## h/t https://stackoverflow.com/questions/69585261/dplyr-if-any-and-numeric-filtering

print(data_0)

## ---------------------------
##' [Working across() Columns]
## ---------------------------

data_0 |>
  select(-UNITID) |>
  count(across(everything(), ~ . == 0))

## ---------------------------
##' [From ifelse() to case_when()]
## ---------------------------

data_18_clean |>
  mutate(highest_cat = case_when(inst_spend > rsch_spend & rsch_spend > serv_spend ~ "inst_rsch_serv",
                                 inst_spend > serv_spend & serv_spend > rsch_spend ~ "inst_serv_rsch",
                                 rsch_spend > inst_spend & inst_spend > serv_spend ~ "rsch_inst_serv",
                                 rsch_spend > serv_spend & serv_spend > inst_spend ~ "rsch_serv_inst",
                                 serv_spend > inst_spend & inst_spend > rsch_spend ~ "serv_inst_rsch",
                                 serv_spend > rsch_spend & rsch_spend > inst_spend ~ "serv_rsch_inst",
                                 TRUE ~ "You missed a condition Matt")) |>
  count(highest_cat)

data_18_clean |>
  mutate(highest_cat = case_when(inst_spend >= rsch_spend & rsch_spend >= serv_spend ~ "inst_rsch_serv",
                                 inst_spend >= serv_spend & serv_spend >= rsch_spend ~ "inst_serv_rsch",
                                 rsch_spend >= inst_spend & inst_spend >= serv_spend ~ "rsch_inst_serv",
                                 rsch_spend >= serv_spend & serv_spend >= inst_spend ~ "rsch_serv_inst",
                                 serv_spend >= inst_spend & inst_spend >= rsch_spend ~ "serv_inst_rsch",
                                 serv_spend >= rsch_spend & rsch_spend >= inst_spend ~ "serv_rsch_inst",
                                 TRUE ~ "You missed a condition Matt")) |>
  count(highest_cat)

# install.packages("tidycensus")
# library(tidycensus)
library(tidycensus)

# census_api_key("<key>", install = T)

data <- get_acs(geography = "tract",
                state = "MN",
                year = 2022,
                survey = "acs5",
                variables = c("DP02_0065PE", "DP03_0119PE"), # Pop >=25 with Bachelors, Pop below poverty line
                output = "wide",
                geometry = FALSE)

ggplot(data) +
  geom_point(aes(x = DP03_0119PE,
                 y = DP02_0065PE))

# install.packages("educationdata")
# library(educationdata)
library(educationdata)

# data_info <- get_education_data(level = "college-university",
#                            source = "ipeds",
#                            topic = "directory",
#                            filters = list(year = 2021),
#                            add_labels = TRUE)
# 
# data_aid <- get_education_data(level = "college-university",
#                            source = "ipeds",
#                            topic = "sfa-by-tuition-type",
#                            filters = list(year = 2021),
#                            add_labels = TRUE)

load("data/ui-ed-data.Rdata")

nrow(data_info)
nrow(data_aid)

data_aid <- data_aid |>
  filter(tuition_type == "Out of state")

nrow(data_aid)

# install.packages("EdSurvey")
# library(EdSurvey)
library(EdSurvey)

# downloadHSLS(".")

# hsls <- readHSLS("HSLS/2009")

# data_hsls <- getData(hsls,
#                      varnames = c("x4evratndclg", "x1paredexpct"))
load("data/ed-survey.Rds")

data_hsls_plot <- data_hsls |>
  group_by(x4evratndclg) |>
  count(x1stuedexpct) |>
  mutate(sum = sum(n),
         perc = n/sum*100) |>
  select(x4evratndclg, x1stuedexpct, perc)

ggplot(data_hsls_plot) +
  geom_col(aes(y = perc, x = x1stuedexpct, fill = x4evratndclg),
           position = "dodge") +
  scale_fill_manual(values = c("pink2", "navy")) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, size = 6)) +
  labs(x = "Student Educational Expectations in Wave 1",
       y = "% of Students Respondants",
       fill = str_wrap("Did the Student Ever Attend College by Wave 4", 30))

download.file(url = "https://www.kaggle.com/api/v1/datasets/download/ben1989/target-store-dataset",
              destfile = "data/target-data.zip")

unzip("data/target-data.zip", exdir = "data/")

data_target <- read_csv("data/targets.csv")

data_target |>
  count(SubTypeDescription)

## ---------------------------
##' [Data Wrangling II in SQL]
## ---------------------------

## ---------------------------
##' [dbplyr SQL Setup]
## ---------------------------


df <- read_csv(file.path("data", "sch-test", "all-schools.csv"))

microsoft_access <- simulate_access()

db <- memdb_frame(df)


## ---------------------------
##' [Create Summary Table]
## ---------------------------

# https://stackoverflow.com/questions/76724279/syntax-highlight-quarto-output
df_sum <- db |>
    ## grouping by year so average within each year
    group_by(year) |>
    ## get mean(<score>) for each test
    summarize(math_m = mean(math),
              read_m = mean(read),
              science_m = mean(science)) |>
  show_query()

## ---------------------------
##' [Left-Join]
## ---------------------------

df_joined <- db |>
    ## pipe into left_join to join with df_sum using "year" as key
    left_join(df_sum, by = "year") |>
  show_query()

## ---------------------------
##' [Pivot-Longer]
## ---------------------------

df_long <- db |>
    ## cols: current test columns
    ## names_to: where "math", "read", and "science" will go
    ## values_to: where the values in cols will go
    pivot_longer(cols = c("math","read","science"),
                 names_to = "test",
                 values_to = "score") |>
  show_query()

## ---------------------------
##' [Pivot-Wider]
## ---------------------------

df_wide <- df_long |>
    ## names_from: values in this column will become new column names
    ## values_from: values in this column will become values in new cols
    pivot_wider(names_from = "test",
                values_from = "score") |>
  show_query()

## ---------------------------
##' [Data Wrangling I in SQL]
## ---------------------------

df <- read_csv(file.path("data", "hsls-small.csv"))

df |>
  ## select columns we want
  select(stu_id, x1stuedexpct, x1paredexpct, x1region) |>
  ## If expectation is -8, -9. or 11, make it NA
  mutate(student_exp = ifelse(x1stuedexpct %in% list(-8, -9, 11), NA, x1stuedexpct),
         parent_exp = ifelse(x1paredexpct %in% list(-8, -9, 11), NA, x1paredexpct)) |>
  ## Make a new variable called high_exp that is the higher or parent and student exp
  mutate(high_exp = ifelse(student_exp > parent_exp, student_exp, parent_exp)) |>
  ## If one exp is NA but the other isn't, keep the value not the NA
  mutate(high_exp = ifelse(is.na(high_exp) & !is.na(student_exp), student_exp, high_exp),
         high_exp = ifelse(is.na(high_exp) & !is.na(parent_exp), parent_exp, high_exp)) |>
  ## Drop is high_exp is still NA (neither parent or student answered)
  filter(!is.na(high_exp)) |>
  ## Group the results by region
  group_by(x1region) |>
  ## Get the mean of high_exp (by region)
  summarize(mean_exp = mean(high_exp))

## ---------------------------
##' [dbplyr SQL Setup]
## ---------------------------


microsoft_access <- simulate_access()

db <- memdb_frame(df)



db |>
  ## select columns we want
  select(stu_id, x1stuedexpct, x1paredexpct, x1region) |>
  ## If expectation is -8, -9. or 11, make it NA
  mutate(student_exp = ifelse(x1stuedexpct %in% list(-8, -9, 11), NA, x1stuedexpct),
         parent_exp = ifelse(x1paredexpct %in% list(-8, -9, 11), NA, x1paredexpct)) |>
  ## Make a new variable called high_exp that is the higher or parent and student exp
  mutate(high_exp = ifelse(student_exp > parent_exp, student_exp, parent_exp)) |>
  ## If one exp is NA but the other isn't, keep the value not the NA
  mutate(high_exp = ifelse(is.na(high_exp) & !is.na(student_exp), student_exp, high_exp),
         high_exp = ifelse(is.na(high_exp) & !is.na(parent_exp), parent_exp, high_exp)) |>
  ## Drop is high_exp is still NA (neither parent or student answereed)
  filter(!is.na(high_exp)) |>
  ## Group the results by region
  group_by(x1region) |>
  ## Get the mean of high_exp (by region)
  summarize(mean_exp = mean(high_exp)) |>
  show_query()


## ---------------------------
##' [Step-by-Step Breakdown]
## ---------------------------

db |>
  ## select columns we want
  select(stu_id, x1stuedexpct, x1paredexpct, x1region) |>
  show_query()

db |>
  ## select columns we want
  select(stu_id, x1stuedexpct, x1paredexpct, x1region) |>
  ## If expectation is -8, -9. or 11, make it NA
  mutate(student_exp = ifelse(x1stuedexpct %in% list(-8, -9, 11), NA, x1stuedexpct),
         parent_exp = ifelse(x1paredexpct %in% list(-8, -9, 11), NA, x1paredexpct)) |>
  show_query()


db |>
  ## select columns we want
  select(stu_id, x1stuedexpct, x1paredexpct, x1region) |>
  ## If expectation is -8, -9. or 11, make it NA
  mutate(student_exp = ifelse(x1stuedexpct %in% list(-8, -9, 11), NA, x1stuedexpct),
         parent_exp = ifelse(x1paredexpct %in% list(-8, -9, 11), NA, x1paredexpct)) |>
  ## Make a new variable called high_exp that is the higher or parent and student exp
  mutate(high_exp = ifelse(student_exp > parent_exp, student_exp, parent_exp)) |>
  show_query()


db |>
  ## select columns we want
  select(stu_id, x1stuedexpct, x1paredexpct, x1region) |>
  ## If expectation is -8, -9. or 11, make it NA
  mutate(student_exp = ifelse(x1stuedexpct %in% list(-8, -9, 11), NA, x1stuedexpct),
         parent_exp = ifelse(x1paredexpct %in% list(-8, -9, 11), NA, x1paredexpct)) |>
  ## Make a new variable called high_exp that is the higher or parent and student exp
  mutate(high_exp = ifelse(student_exp > parent_exp, student_exp, parent_exp)) |>
  ## If one exp is NA but the other isn't, keep the value not the NA
  mutate(high_exp = ifelse(is.na(high_exp) & !is.na(student_exp), student_exp, high_exp),
         high_exp = ifelse(is.na(high_exp) & !is.na(parent_exp), parent_exp, high_exp)) |>
  show_query()

db |>
  ## select columns we want
  select(stu_id, x1stuedexpct, x1paredexpct, x1region) |>
  ## If expectation is -8, -9. or 11, make it NA
  mutate(student_exp = ifelse(x1stuedexpct %in% list(-8, -9, 11), NA, x1stuedexpct),
         parent_exp = ifelse(x1paredexpct %in% list(-8, -9, 11), NA, x1paredexpct)) |>
  ## Make a new variable called high_exp that is the higher or parent and student exp
  mutate(high_exp = ifelse(student_exp > parent_exp, student_exp, parent_exp)) |>
  ## If one exp is NA but the other isn't, keep the value not the NA
  mutate(high_exp = ifelse(is.na(high_exp) & !is.na(student_exp), student_exp, high_exp),
         high_exp = ifelse(is.na(high_exp) & !is.na(parent_exp), parent_exp, high_exp)) |>
  ## Drop is high_exp is still NA (neither parent or student answereed)
  filter(!is.na(high_exp)) |>
  show_query()

db |>
  ## select columns we want
  select(stu_id, x1stuedexpct, x1paredexpct, x1region) |>
  ## If expectation is -8, -9. or 11, make it NA
  mutate(student_exp = ifelse(x1stuedexpct %in% list(-8, -9, 11), NA, x1stuedexpct),
         parent_exp = ifelse(x1paredexpct %in% list(-8, -9, 11), NA, x1paredexpct)) |>
  ## Make a new variable called high_exp that is the higher or parent and student exp
  mutate(high_exp = ifelse(student_exp > parent_exp, student_exp, parent_exp)) |>
  ## If one exp is NA but the other isn't, keep the value not the NA
  mutate(high_exp = ifelse(is.na(high_exp) & !is.na(student_exp), student_exp, high_exp),
         high_exp = ifelse(is.na(high_exp) & !is.na(parent_exp), parent_exp, high_exp)) |>
  ## Drop is high_exp is still NA (neither parent or student answered)
  filter(!is.na(high_exp)) |>
  ## Group the results by region
  group_by(x1region) |>
  summarize(mean_exp = mean(high_exp)) |>
  show_query()

## ---------------------------
##' [Pivot-Longer with Compound Names]
## ---------------------------


df_3 <- read_csv(file.path("data", "sch-test", "all-schools-wide.csv"))

db_3 <- memdb_frame(df_3)

print(db_3)


## Note: change from DWII,dbplyr can't translate separate, or any stringr commands, so we have to be more sophisticated with our pivot_longer
df_long_fix <- db_3 |>
    ## NB: contains() looks for "19" in name: if there, it adds it to cols
    pivot_longer(cols = contains("19"),
                 names_to = c("test", "year"),
                 names_sep = "_",
                 values_to = "score") |>
  show_query()

